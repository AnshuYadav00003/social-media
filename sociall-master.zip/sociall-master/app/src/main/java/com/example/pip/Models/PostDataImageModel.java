package com.example.pip.Models;

public class PostDataImageModel {
    public String pipImageData;
    public PostDataImageModel(){

    }
    public PostDataImageModel(String pipImageData){
        this.pipImageData = pipImageData;
    }
}
