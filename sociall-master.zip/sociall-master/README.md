# pip

</br>

### Pip in light mode 
<div>
<img src="https://user-images.githubusercontent.com/69726226/195368505-1b41d329-84d2-480e-a9ef-6cd752195416.jpg" width=" 200px">
<img src="https://user-images.githubusercontent.com/69726226/195368854-8ab39f1f-db15-413e-b53c-ae42ad988f9f.jpg" width="200px">
<img src="https://user-images.githubusercontent.com/69726226/195368979-ba248686-c6d9-43dd-8591-890e5e4d04a7.jpg" width="200px">
<img src="https://user-images.githubusercontent.com/69726226/195369118-8673bf76-3a37-494c-84ec-46faa268734c.jpg"   width="200px">
<img src="https://user-images.githubusercontent.com/69726226/195369245-e35d2f84-381d-464b-91df-5c0cc1fa4095.jpg" width="200px">  
<img src="https://user-images.githubusercontent.com/69726226/195369426-14bc5399-14a6-4b08-9758-333ff4489c2d.jpg"  width="200px">    
<img src="https://user-images.githubusercontent.com/69726226/195369488-3e6d8464-a645-4c39-9308-f515d6779f58.jpg"   width="200px">  
<img src="https://user-images.githubusercontent.com/69726226/195369616-626427ff-0626-42ce-933b-7923df3a405d.jpg" width="200px">  
<img src="https://user-images.githubusercontent.com/69726226/195369731-b6c87458-f2f7-4db3-8214-d02240e0f9ea.jpg"  width="200px">  
<img src="https://user-images.githubusercontent.com/69726226/195369836-23961879-4fdb-4bc4-a114-b3ea98ad0ce5.jpg"  width="200px">    
<img src="https://user-images.githubusercontent.com/69726226/195370080-ec4337b9-7992-4772-bfa2-4d1823c3c8b5.jpg"  width="200px">    
<img src="https://user-images.githubusercontent.com/69726226/195370189-abc80958-485d-4a1d-a276-dcc3089dd041.jpg"  width="200px">    
<img src="https://user-images.githubusercontent.com/69726226/195370297-fb630e51-e0c1-4686-9f35-8dba3e4282d8.jpg"  width="200px">
</div>
  
</br>
  
 ### Pip in dark mode 
<div>    
<img src="https://user-images.githubusercontent.com/69726226/195370960-9c861ab4-15fb-4b6c-8cb9-13d89d7c028e.jpg"  width="200px">    
<img src="https://user-images.githubusercontent.com/69726226/195371067-e093444a-da3f-4b24-8b44-35e51967144d.jpg"  width="200px">      
<img src="https://user-images.githubusercontent.com/69726226/195371173-2312d5c8-8000-47ab-9afc-7551af4bd779.jpg"  width="200px">    
<img src="https://user-images.githubusercontent.com/69726226/195371485-28741e47-98b0-45b0-b81b-82eed57701a8.jpg"  width="200px">      
<img src="https://user-images.githubusercontent.com/69726226/195371549-bc8b9714-d125-4106-965b-60136cb45cfb.jpg"  width="200px">    
<img src="https://user-images.githubusercontent.com/69726226/195371618-196834c4-eeb2-441a-9665-d38dd6ebeb2d.jpg"  width="200px">      
<img src="https://user-images.githubusercontent.com/69726226/195371694-92a1e12f-a853-4e71-aead-01772209948d.jpg"  width="200px">    
<img src="https://user-images.githubusercontent.com/69726226/195371831-6f7c5d5b-7084-4560-bd29-4ea2362711ff.jpg"  width="200px">      
<img src="https://user-images.githubusercontent.com/69726226/195371914-1db84f0f-70e0-4d3b-9b95-d14ad3e2b216.jpg"  width="200px">    
<img src="https://user-images.githubusercontent.com/69726226/195372014-8ae4d7fc-44c7-4f2a-a1b8-f879883d2271.jpg"  width="200px">      
<img src="https://user-images.githubusercontent.com/69726226/195372093-d7b3bb49-104e-470c-8acb-83ca8c8e54d4.jpg"  width="200px">    
<img src="https://user-images.githubusercontent.com/69726226/195372201-cae128cf-bdbd-4e15-ad59-80382b2d0b9e.jpg"  width="200px">      
<!-- <img src=""  width="200px"> -->
    
<!-- <img src="https://user-images.githubusercontent.com/69726226/195369836-23961879-4fdb-4bc4-a114-b3ea98ad0ce5.jpg"  width="200px"> -->

   
</div>
